<!DOCTYPE html>
<html>
<head>
	<title> page error 404</title>
</head>
<body>
	<center><img src="error.png" width="800" height="300">

	<p><h2>This page is under maintenance</h2></p>
	<p><h2>Please try again next time :)</h2></p>

    </center>

</body>
</html>